create procedure pro()
  BEGIN
-- 声明一个int类型的变量
	DECLARE i INT;
	SET i = 0;
	WHILE i < 1000 DO
		INSERT INTO t_luminosity(orderId,proId,cyl,sph,amount)
		VALUES(3265,2564,-25,-1*i,2.5);
		SET i = i + 25;
	END WHILE;
-- 结束
END;

